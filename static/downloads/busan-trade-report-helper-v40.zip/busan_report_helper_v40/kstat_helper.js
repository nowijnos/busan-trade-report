'use strict';
// Runs only in user's visible K-Stat page. No reading/storing of credentials, cookies or sessions.
// Source page access is limited to the known K-Stat product screen by manifest host_permissions.
if (!globalThis.__busanKstatHelperV40Ready) {
  globalThis.__busanKstatHelperV40Ready = true;
  const allowedKeys = new Set(['mti2_exp_month','mti2_exp_current','mti2_exp_prior','mti2_imp_month','mti2_imp_current','mti2_imp_prior','china_month','china_current','china_prior']);
  const trim = s => String(s || '').replace(/\s+/g,' ').trim().slice(0,80);
  const visible = e => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
  const byName = name => document.querySelector(`select[name="${name}"]`);
  const inputByName = name => document.querySelector(`input[name="${name}"]`);
  const selectOptions = el => Array.from(el?.options || []).map(o => ({text:trim(o.textContent),value:o.value}));
  const hasValue = (el,v) => selectOptions(el).some(o => o.value === String(v));
  const onPage = () => location.origin === 'https://stat.kita.net' && location.pathname === '/stat/kts/prod/ProdItemImpExpList.screen';
  function hint(el) {
    if(el.id) {const lab=document.querySelector(`label[for="${CSS.escape(el.id)}"]`);if(lab)return trim(lab.textContent);}
    const lab=el.closest('label');if(lab)return trim(lab.textContent);
    const row=el.closest('tr');if(row){const heads=Array.from(row.querySelectorAll('th')).map(x=>trim(x.textContent)).filter(Boolean);if(heads.length)return heads.join(' / ').slice(0,80);}
    const prev=el.previousElementSibling;if(prev&&trim(prev.textContent).length<45)return trim(prev.textContent);
    return trim(el.parentElement?.parentElement?.querySelector('label, th')?.textContent);
  }
  function actionLabel(e){if(!e)return '';return trim(e.getAttribute('aria-label')||e.getAttribute('alt')||e.getAttribute('title')||e.getAttribute('value')||e.textContent);}
  function diagnostic() {
    if(!onPage())throw Error('K-Stat 품목별 지자체 수출입 화면에서 실행하세요.');
    const controls = Array.from(document.querySelectorAll('select,input:not([type=hidden]),button'))
      .filter(visible).filter(e=>!['password','email','tel'].includes(e.type)).slice(0,120).map((e,index)=>({
        index,tag:e.tagName.toLowerCase(),id:e.id||'',name:e.name||'',hint:hint(e),
        options:e.tagName==='SELECT'?selectOptions(e).slice(0,120):[],
        inputType:e.getAttribute('type')||'',readOnly:!!e.readOnly
      }));
    const actions = Array.from(document.querySelectorAll('button,input[type=button],input[type=submit],a,[role=button],img[alt],img[title]'))
      .filter(visible).map(e=>({tag:e.tagName.toLowerCase(),id:(e.id||'').slice(0,65),name:(e.name||'').slice(0,65),
        label:actionLabel(e),type:(e.getAttribute('type')||'').slice(0,25)}))
      .filter(x=>/조회|검색|다운로드|엑셀|excel|출력|지역|국가|선택|저장/i.test(x.label)).slice(0,40);
    return {source:'K-Stat 품목별 지자체 수출입',page:location.pathname,
      counts:{select:document.querySelectorAll('select').length,inputs:document.querySelectorAll('input').length},
      controls,actions,actionStructure:uiProbe().buttons,mti3OptionVisible:hasValue(byName('s_cond_unit'),'3'),
      note:'개인정보 제외: 로그인·사용자 입력값·선택 지역/국가·세션·쿠키·요청 헤더·통계 결과·URL 매개변수는 수집하지 않습니다.'};
  }
  function validateMsg(msg) {
    if(!onPage())throw Error('K-Stat 품목별 지자체 수출입 화면에서만 가능합니다.');
    if(!allowedKeys.has(msg?.key))throw Error('정의되지 않은 수집 단계입니다.');
    const year=Number(msg?.period?.year),month=Number(msg?.period?.month);
    if(!Number.isInteger(year)||year<2000||year>2100||!Number.isInteger(month)||month<1||month>12)throw Error('보고서 기준연월 오류');
    const prior=msg.key.endsWith('prior'),monthly=msg.key.endsWith('month'),china=msg.key.startsWith('china');
    const target = {
      s_cond_gb:'MTI',s_cond_unit:china?'3':'2',s_year:String(prior?year-1:year),
      s_month:String(month).padStart(2,'0'),s_monthsum_gb:monthly?'1':'2',s_field:'AMT',s_measure:'1',
      s_sort:(china||msg.key.startsWith('mti2_imp_'))?'THIS_IMP_AMT':'THIS_EXP_AMT'
    };
    // Codes are user-confirmed K-Stat region/country codes; not login credentials.
    // MTI2: country=all (blank), China MTI3: country=CN.
    return {target,china,scope:{region:'60',country:china?'CN':''}};
  }
  // This is a display-only correction for K-Stat's stale region-name text.
  // It never writes a selection name into an input, changes K-Stat query parameters,
  // or claims that reading code 60 alone proves the returned statistics are Busan's.
  const REGION_NOTE_ID='busan-kstat-region-inline-v30';
  let correctedLabel=null, observedHost=null, regionObserver=null, regionSyncPending=false;
  let currentScope=null;
  function oldFloatingBannerGone(){
    // v27/v28 drew a fixed banner. It could cover content; remove it on upgrade.
    document.getElementById('busan-kstat-code-indicator-v27')?.remove();
  }
  function nearestRegionNameNode(region,name){
    const box=region.getBoundingClientRect();
    if(!box.width||!box.height)return null;
    let host=region.parentElement;
    for(let depth=0;host&&host!==document.body&&depth<7;host=host.parentElement,depth++){
      // Check only visible standalone name text very close to the region-code field.
      const walker=document.createTreeWalker(host,NodeFilter.SHOW_TEXT);
      const matches=[];let node,scanned=0;
      while((node=walker.nextNode())&&++scanned<900){
        if(node.nodeValue?.trim()!==name||node.parentElement?.closest(`#${REGION_NOTE_ID}`))continue;
        const parent=node.parentElement;
        if(!parent||/^(SCRIPT|STYLE|NOSCRIPT)$/.test(parent.tagName))continue;
        const range=document.createRange();range.selectNodeContents(node);
        const rect=range.getBoundingClientRect();
        if(!rect.width||!rect.height)continue;
        const dy=Math.abs((rect.top+rect.bottom)/2-(box.top+box.bottom)/2);
        const dx=rect.left-box.right;
        // Region display sits to the RIGHT of '60 [선택]' on the same row.
        if(dy>23||dx< -7||dx>300)continue;
        matches.push({node,score:dy*4+Math.max(0,dx)*.07});
      }
      matches.sort((x,y)=>x.score-y.score);
      if(matches.length && (matches.length===1 || matches[1].score-matches[0].score>5))return matches[0].node;
      if(matches.length)return null; // ambiguous native labels: do not modify
    }
    return null;
  }
  function clearLocalPresentation(){
    const old=correctedLabel;
    if(old&&old.node.isConnected&&old.node.nodeValue==='부산')old.node.nodeValue=old.original;
    correctedLabel=null;
    document.getElementById(REGION_NOTE_ID)?.remove();
  }
  function smallInlineNotice(region){
    const host=region.closest('td')||region.parentElement;
    if(!host)return;
    let note=document.getElementById(REGION_NOTE_ID);
    if(!note){note=document.createElement('div');note.id=REGION_NOTE_ID;note.setAttribute('role','status');}
    // An ordinary block inside the filter row, not a fixed overlay. It pushes
    // subsequent rows down when necessary instead of covering form controls.
    note.style.cssText='display:block;clear:both;position:static;float:none;pointer-events:auto;max-width:340px;white-space:normal;margin:4px 0 1px;padding:4px 6px;border-left:3px solid #2876aa;background:#eef7ff;color:#234b6a;font:11px/1.45 "Malgun Gothic",sans-serif;box-sizing:border-box;';
    const noteText='※ 지역코드 60 = 부산. 옆의 ‘전국’은 갱신되지 않은 표시일 수 있어요. 조회 결과도 확인하세요.';
    if(note.textContent!==noteText)note.textContent=noteText;
    if(note.parentElement!==host)host.appendChild(note);
  }
  function syncRegionPresentation(){
    oldFloatingBannerGone();
    const region=inputByName('s_prod_code'),country=inputByName('s_ctr_code');
    if(!region||!country||!currentScope||region.value.trim()!=='60'||country.value.trim()!==currentScope.country){
      clearLocalPresentation();return;
    }
    // If the site already displays Busan correctly, don't touch its own DOM.
    const preExistingBusan=nearestRegionNameNode(region,'부산');
    if(preExistingBusan){
      document.getElementById(REGION_NOTE_ID)?.remove();return;
    }
    const nativeName=nearestRegionNameNode(region,'전국');
    if(nativeName){
      if(correctedLabel&&correctedLabel.node!==nativeName)clearLocalPresentation();
      // The site may keep its own selected region label stale. Do NOT change its wording.
      // A cosmetic '부산' label would conceal a real mismatch in the exported result.
      smallInlineNotice(region);
      return;
    }
    // Unknown markup (including a readonly input label): never guess a selector.
    // Keep the genuine UI intact and show a short, in-flow explanation instead.
    smallInlineNotice(region);
  }
  function queueRegionSync(){
    if(regionSyncPending)return;
    regionSyncPending=true;
    setTimeout(()=>{regionSyncPending=false;syncRegionPresentation();},70);
  }
  function ensureRegionDisplayWatch(){
    const region=inputByName('s_prod_code');
    if(!region)return;
    const host=region.closest('tr')||region.parentElement;
    if(host&&host!==observedHost){
      regionObserver?.disconnect();
      regionObserver=new MutationObserver(queueRegionSync);
      regionObserver.observe(host,{subtree:true,childList:true,characterData:true});
      observedHost=host;
    }
    if(!region.dataset.busanRegionV30Listener){
      region.dataset.busanRegionV30Listener='1';
      region.addEventListener('input',queueRegionSync);
      region.addEventListener('change',queueRegionSync);
    }
  }
  function showVerifiedCode(scope){
    currentScope=scope;
    ensureRegionDisplayWatch();
    syncRegionPresentation();
    // Some site scripts update their display label asynchronously after change.
    setTimeout(syncRegionPresentation,250);
    setTimeout(syncRegionPresentation,900);
  }
  function setInputCode(name, value, done, missing, label){
    const el=inputByName(name);
    if(!el || el.disabled || el.readOnly || el.type==='password'){
      missing.push(label+' 입력칸을 수정할 수 없음');return false;
    }
    if(el.value.trim() !== value){
      // Native setter and input/change simulate ordinary form entry, never bypass authentication.
      const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set;
      if(setter) setter.call(el,value); else el.value=value;
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    }
    if(el.value.trim()!==value){
      missing.push(label+' 코드가 적용되지 않음 (팝업에서 직접 선택 필요)');return false;
    }
    done.push(label+': '+(value||'전체 (빈 코드)')+' [입력칸 값 확인]');
    return true;
  }
  function checkScope(scope,missing){
    for(const [field,want,label] of [
      ['s_prod_code',scope.region,'부산 지역코드'],
      ['s_ctr_code',scope.country,'국가코드']
    ]){
      const el=inputByName(field);
      if(!el || el.disabled || el.value.trim()!==want){
        missing.push(label+' '+(want||'전체')+' 확인 안 됨 (선택 팝업에서 직접 지정 가능)');
      }
    }
  }
  function setSelect(name,value,done,missing,desc,optional=false){
    const el=byName(name);
    if(!el||!hasValue(el,value)){if(!optional)missing.push(`${desc}: '${value}' 선택항목 없음`);return false;}
    if(el.value!==String(value)){
      el.value=String(value);
      el.dispatchEvent(new Event('input',{bubbles:true}));
      el.dispatchEvent(new Event('change',{bubbles:true}));
    }
    if(el.value!==String(value)){if(!optional)missing.push(`${desc}: 값이 유지되지 않음`);return false;}
    done.push(`${desc}: ${el.options[el.selectedIndex]?.textContent.trim()||value}`);
    return true;
  }
  async function waitForValue(name,v,ms=2400){const start=Date.now();while(Date.now()-start<ms){if(hasValue(byName(name),v))return true;await new Promise(r=>setTimeout(r,120));}return false;}
  function setSortDescending(done,missing){
    const radio=document.getElementById('s_sort_val_desc') ||
      Array.from(document.querySelectorAll('input[type="radio"][name="s_sort_val"]')).find(x=>/desc/i.test(x.id||x.value||''));
    if(!radio || radio.disabled){missing.push('정렬: 내림차순 선택 버튼 없음');return false;}
    if(!radio.checked){
      const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'checked')?.set;
      if(setter)setter.call(radio,true);else radio.checked=true;
      radio.dispatchEvent(new Event('input',{bubbles:true}));
      radio.dispatchEvent(new Event('change',{bubbles:true}));
    }
    if(!radio.checked){missing.push('정렬 내림차순이 적용되지 않음');return false;}
    done.push('정렬 방향: 내림차순');return true;
  }
  async function prepare(msg){
    const {target,china,scope}=validateMsg(msg),done=[],missing=[];
    setSelect('s_cond_gb',target.s_cond_gb,done,missing,'품목');
    await waitForValue('s_cond_unit',target.s_cond_unit);
    const ds={s_cond_unit:'MTI단위',s_year:'연도',s_month:'월',s_monthsum_gb:'당월/누계',s_field:'화면',s_measure:'금액 단위',s_sort:(china||msg.key.startsWith('mti2_imp_'))?'수입금액 정렬':'수출금액 정렬'};
    for(const [k,name] of Object.entries(ds))setSelect(k,target[k],done,missing,name);
    setSortDescending(done,missing);
    // The 50-row dropdown controls page presentation, not guaranteed Excel export scope.
    // Keep it optional, so a changed K-Stat UI does not break the six reports.
    setSelect('listCount','100',done,missing,'목록 표시: 100개씩 보기',true);
    // Set codes last; some K-Stat handlers reset region/country when category or month changes.
    setInputCode('s_prod_code',scope.region,done,missing,'지역(부산)');
    setInputCode('s_ctr_code',scope.country,done,missing,china?'국가(중국)':'국가(전체)');
    showVerifiedCode(scope);
    return {ok:!missing.length,done,missing,
      message:`${done.join('\n')}\n${missing.length?'\n설정 불가: '+missing.join(', '):''}\n\n주의: 코드 입력만으로 K-Stat의 지역·국가 선택 팝업 상태까지 반영되는지는 아직 확인되지 않았습니다. 코드 60이더라도 원래 지역 설명에 '전국' 글씨가 남을 수 있으니 실제 통계표와 적용코드를 확인해 주세요.\n검증 후 체크박스를 선택해야 조회할 수 있습니다.`,
      mti3OptionVisible:hasValue(byName('s_cond_unit'),'3')};
  }
  function checkCurrent(msg) {
    const {target,china,scope}=validateMsg(msg);
    const missing=[];
    for(const [name,want] of Object.entries(target)){
      const el=byName(name);
      if(!el||el.value!==want)missing.push(`${name} (${name==='s_cond_unit'?'MTI 단위':name==='s_monthsum_gb'?'당월/누계':'조회 조건'})`);
    }
    checkScope(scope,missing);
    const desc=document.getElementById('s_sort_val_desc');
    if(!desc || !desc.checked)missing.push('정렬 기준: 내림차순 미설정');
    return {ok:missing.length===0,missing,china,scopeVerifiedByInput:missing.length===0};
  }
  // Prefer the actual event-bearing ancestor over a decorative IMG. The v20 helper
  // clicked the IMG itself and reported success without verifying a page response.
  function clickableAncestor(e){
    if(!e)return null;
    let n=e;
    for(let i=0;i<5 && n && n!==document.body;i++,n=n.parentElement){
      if(n.matches?.('a,button,input[type="button"],input[type="submit"],[role="button"],[onclick]') ||
         typeof n.onclick==='function')return n;
    }
    return e;
  }
  function candidates(kind){
    const elements=Array.from(document.querySelectorAll('a,button,input[type="button"],input[type="submit"],img[alt],img[title]'))
      .filter(visible);
    if(kind==='query')return [...new Set(elements.filter(e=>/^(조회|검색)$/.test(actionLabel(e))).map(clickableAncestor))];
    // Some K-Stat pages display an outer "다운로드" image and the actual
    // "엑셀다운" link in a popup/menu. Handle them as separate stages.
    if(kind==='excel')return [...new Set(elements.filter(e=>/^엑셀\s*다운$/.test(actionLabel(e))).map(clickableAncestor))];
    if(kind==='downloadMenu')return [...new Set(elements.filter(e=>/^다운로드$/.test(actionLabel(e))).map(clickableAncestor))];
    return [];
  }
  // Inspect the current *visible result rows*, not just selected form controls.
  // No trade amounts, table text or customer data leave this tab: only counts and
  // a non-reversible 32-bit change fingerprint are returned to the extension.
  function auditResult(msg){
    const expectedDigits=msg?.key?.startsWith('china_')?3:2;
    const condition=checkCurrent(msg);
    const surveys=[];
    for(const table of document.querySelectorAll('table')){
      if(!visible(table))continue;
      const rows=[...table.querySelectorAll('tr')].filter(visible);
      if(rows.length<3)continue;
      const detected=[];
      const raw=[];
      for(const row of rows){
        const cells=[...row.querySelectorAll('td')].filter(visible);
        if(cells.length<3)continue;
        const values=cells.map(x=>String(x.textContent||'').trim());
        // A true K-Stat product row has a 2/3-digit MTI code near the left.
        // Search up to four cells because some layouts show row numbers first.
        const first=values.slice(0,Math.min(4,values.length));
        let code='';
        for(const cell of first){
          const m=cell.replace(/\s+/g,'').match(/^(\d{2,6})(?=$|[^\d])/);
          if(m && m[1].length<=6){code=m[1];break;}
        }
        if(!code)continue;
        // Exclude option/metadata tables: require at least two numeric amounts
        // outside the leftmost 4 cells, or one amount if the table is narrower.
        const numeric=values.slice(Math.min(2,values.length-1)).filter(v=>/^[-+]?\d[\d,]*(?:\.\d+)?%?$/.test(v)).length;
        if(numeric<1)continue;
        detected.push(code);
        raw.push(values.slice(0,Math.min(8,values.length)).join('|'));
      }
      if(detected.length)surveys.push({codes:detected,raw,score:detected.length});
    }
    surveys.sort((a,b)=>b.score-a.score);
    const chosen=surveys[0]||{codes:[],raw:[]};
    const total=chosen.codes.length;
    const correct=chosen.codes.filter(code=>code.length===expectedDigits).length;
    const wrong=total-correct;
    // Used solely to ensure a new query did not merely leave the previous table.
    const sample=chosen.raw.slice(0,50).join('\n');
    let hash=2166136261;
    for(let i=0;i<sample.length;i++){
      hash^=sample.charCodeAt(i);
      hash=Math.imul(hash,16777619)>>>0;
    }
    const fingerprint=total?hash.toString(16)+'-'+total:'';
    let reason='';
    if(!condition.ok)reason='조회 조건 불일치: '+condition.missing.join(', ');
    else if(total===0)reason='K-Stat 조회 결과표의 품목 행을 찾지 못했습니다. 표에 실제 수치가 나온 뒤 재조회하세요.';
    else if(correct<3 || wrong>correct/3)reason=`품목 코드가 MTI ${expectedDigits}자리와 맞지 않습니다. 확인한 ${total}개 중 ${correct}개만 일치합니다. 이전 조회 결과 또는 잘못된 품목표가 남아 있을 수 있습니다.`;
    return {ok:!reason,reason,detected:total>0,totalRows:total,correctRows:correct,wrongRows:wrong,
      fingerprint,unit:expectedDigits,conditionsOk:condition.ok};
  }
  function statusOfResults(){
    // Never send statistics or user-specific values to the extension.
    // Only the number of records, if an explicit result counter is available.
    const texts=[];
    const nodes=document.querySelectorAll('span,div,td,th,p,strong,b');
    for(const n of nodes){
      if(!visible(n)||n.children.length>3)continue;
      const t=trim(n.textContent);
      if(/전체\s*[0-9,]+\s*건/.test(t) || /^[0-9,]+\s*건$/.test(t))texts.push(t);
      if(texts.length>=25)break;
    }
    let count=null;
    for(const t of texts){
      const m=t.match(/(?:전체\s*)?([0-9,]+)\s*건/);
      if(m){const v=Number(m[1].replace(/,/g,''));if(Number.isFinite(v)&&v>=0){count=v;break;}}
    }
    // The live K-Stat screen may render the result grid without the textual
    // "전체 N건" counter. Detect a visible table with several numeric result
    // cells as a secondary signal; no cell contents leave the page.
    let tableRows=0;
    for(const table of document.querySelectorAll('table')){
      if(!visible(table))continue;
      const rows=[...table.querySelectorAll('tr')].filter(visible);
      if(rows.length<3)continue;
      const header=trim(table.querySelector('thead')?.textContent||rows[0]?.textContent);
      if(!/수출|수입|품목|금액/.test(header))continue;
      const data=rows.slice(1);
      const hasNumbers=data.some(row=>[...row.querySelectorAll('td')].some(td=>/\d[\d,.]*/.test(td.textContent||'')));
      if(hasNumbers)tableRows=Math.max(tableRows,data.length);
    }
    return {detected:count!==null||tableRows>0,hasRecords:(count!==null&&count>0)||tableRows>0,count:count??tableRows,tableDetected:tableRows>0};
  }
  function elementMeta(el){
    return {tag:el.tagName.toLowerCase(),label:actionLabel(el)||actionLabel(el.querySelector?.('img')),
      // Structural diagnostics only. Do not include href, onclick source or sensitive data.
      hasNativeHandler:typeof el.onclick==='function'||el.hasAttribute?.('onclick'),
      parentChain:[el.parentElement?.tagName||'',el.parentElement?.parentElement?.tagName||''].filter(Boolean)};
  }
  function queryElementStructure(){
    // Structural details only: no URL, inline script, field values, user data.
    const nodes=Array.from(document.querySelectorAll('img[alt],img[title],button,input[type=button],a'))
      .filter(visible).filter(e=>/^(조회|검색)$/.test(actionLabel(e))).slice(0,5);
    return nodes.map(e=>({targetTag:e.tagName.toLowerCase(),chain:[e,e.parentElement,e.parentElement?.parentElement].filter(Boolean).map(n=>({
      tag:n.tagName.toLowerCase(),hasOnclick:!!(n.hasAttribute?.('onclick')||typeof n.onclick==='function'),
      anchor:n.tagName==='A',hasHref:!!n.hasAttribute?.('href'),
      role:(n.getAttribute?.('role')||'').slice(0,20),
      classNames:trim(n.className?.baseVal||n.className||'').slice(0,80)
    }))}));
  }
  function uiProbe(){
    const kinds=['query','downloadMenu','excel'];
    return {result:statusOfResults(),queryStructure:queryElementStructure(),buttons:Object.fromEntries(kinds.map(k=>[k,candidates(k).slice(0,5).map(elementMeta)])),
      note:'조회 결과 건수와 버튼 구조만 진단합니다. 조회 내용, 주소, 쿠키, 세션, 인증 정보는 포함하지 않습니다.'};
  }
  function queryAction(msg){
    const v=checkCurrent(msg);
    if(!v.ok)return {ok:false,message:'조건 불일치: '+v.missing.join(', ')};
    if(msg?.confirmed!==true)return {ok:false,message:'부산/국가 선택 확인이 필요합니다.'};
    return {ok:false,message:'이전 조회 방식은 사용하지 않습니다. 페이지 안에서 직접 실행하는 v22 조회 버튼을 사용하세요.'};
  }
  function excelAction(msg){
    // Excel download runs in MAIN world via popup.js, never from this isolated content script.
    const v=checkCurrent(msg);
    if(!v.ok)return {ok:false,message:'조건 불일치: '+v.missing.join(', ')};
    return {ok:false,message:'v23의 [④ 엑셀다운 실행]에서 페이지 내부 실행 방식을 사용해 주세요.'};
  }
  chrome.runtime.onMessage.addListener((msg,_sender,respond)=>{
    if(msg?.type==='KSTAT_DIAG'){try{respond(diagnostic());}catch(e){respond({error:e.message});}return;}
    if(msg?.type==='KSTAT_PREPARE'){
      prepare(msg).then(respond).catch(e=>respond({ok:false,message:e.message,missing:[e.message],done:[]}));return true;
    }
    if(msg?.type==='KSTAT_RESULT_AUDIT') {try{respond(auditResult(msg));}catch(e){respond({ok:false,reason:'조회 결과 검사 오류: '+e.message});}return;}
    if(msg?.type==='KSTAT_RESULT_STATUS') {try{respond({ok:true,...statusOfResults()});}catch(e){respond({ok:false,message:e.message});}return;}
    if(msg?.type==='KSTAT_BUTTON_PROBE') {try{respond({ok:true,...uiProbe()});}catch(e){respond({ok:false,message:e.message});}return;}
    if(msg?.type==='KSTAT_CHECK') {try{respond(checkCurrent(msg));}catch(e){respond({ok:false,message:e.message});}return;}
    if(msg?.type==='KSTAT_CLICK_QUERY') {try{respond(queryAction(msg));}catch(e){respond({ok:false,message:e.message});}return;}
    if(msg?.type==='KSTAT_CLICK_EXCEL') {try{respond(excelAction(msg));}catch(e){respond({ok:false,message:e.message});}return;}
  });
}
