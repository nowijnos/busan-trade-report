'use strict';
// Country-rank viewer only. Never changes the regular 9-file workflow.
if (!globalThis.__busanCountryAnalysisV45) {
 globalThis.__busanCountryAnalysisV45=true;
 const TARGET='/stat/kts/prod/ProdCtrImpExpList.screen';
 const txt=e=>String(e?.textContent||'').replace(/\s+/g,' ').trim();
 const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
 const field=n=>document.querySelector(`[name="${n}"]`);
 const norm=s=>String(s||'').replace(/\s/g,'').replace(/[＄]/g,'$').replace(/[％]/g,'%').toUpperCase();
 const events=e=>{for(const name of ['input','change'])e.dispatchEvent(new Event(name,{bubbles:true}));};
 const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 const nativeSet=(e,v)=>{
  const d=Object.getOwnPropertyDescriptor(e.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype,'value');
  if(d?.set)d.set.call(e,String(v));else e.value=String(v);
  events(e);
 };
 function optSelect(e,value,description,opts={}){
  if(!e || e.tagName!=='SELECT'){
   if(opts.optional)return null;
   throw Error(`${description}: 선택상자가 없습니다. (${e?.name||'없음'})`);
  }
  let option=[...e.options].find(x=>x.value===String(value));
  if(!option && opts.text){option=[...e.options].find(x=>norm(txt(x))===norm(opts.text));}
  if(!option){throw Error(`${description}: 해당 항목을 찾지 못했습니다. 선택 가능: ${[...e.options].map(x=>txt(x)).slice(0,10).join(' / ')}`);}
  nativeSet(e,option.value);
  if(e.value!==option.value)throw Error(`${description}: 값 적용 실패`);
  return txt(e.selectedOptions[0]);
 }
 function textSelect(e,wants,description){
  if(!e||e.tagName!=='SELECT')throw Error(`${description} 선택상자가 없습니다 (s_measure).`);
  const matches=[...e.options].filter(x=>wants.some(w=>norm(txt(x))===norm(w)));
  if(matches.length!==1){
   throw Error(`${description}: 'US$, %' 선택지를 확인할 수 없습니다. 실제 항목: ${[...e.options].map(x=>txt(x)).join(' / ').slice(0,220)}`);
  }
  nativeSet(e,matches[0].value);
  if(e.value!==matches[0].value)throw Error(`${description} 선택이 적용되지 않았습니다.`);
  return txt(e.selectedOptions[0]);
 }
 function fill(e,value,description){
  if(!e||e.tagName!=='INPUT'||e.disabled||e.readOnly||e.type==='hidden')throw Error(`${description} 입력칸이 유효하지 않습니다.`);
  nativeSet(e,value);e.dispatchEvent(new Event('blur',{bubbles:true}));
  if(e.value.trim()!==String(value))throw Error(`${description}가 입력 상태로 유지되지 않았습니다.`);
 }
 function productInput(){
  // K-Stat page versions use different names. Resolve by explicit naming FIRST.
  const names=['s_item_code','s_item_cd','s_mti_code','s_mti_cd','s_item','s_code','s_prod_item_code','s_prod_item','s_hs_code','s_hs_cd','s_start_code','s_start_cd'];
  for(const n of names){const e=document.querySelector(`input[name="${n}"]`);if(e&&visible(e)&&!e.readOnly&&!e.disabled&&e.type!=='hidden')return e;}
  const candidates=[];
  for(const e of document.querySelectorAll('input')){
   if(!visible(e)||e.readOnly||e.disabled||e.type==='hidden'||['radio','checkbox','button','image'].includes(e.type))continue;
   if(['s_prod_code','s_ctr_code','s_year','s_month'].includes(e.name))continue;
   if(/(item|mti|hs|prod|start|code)/i.test((e.name||'')+' '+(e.id||'')) && !/(year|month|sort|unit|user|login|search)/i.test((e.name||'')+' '+(e.id||'')))candidates.push(e);
  }
  const unique=[...new Set(candidates)];
  if(unique.length===1)return unique[0];
  // Locate a field under the actual '품목' or '시작코드' row/label (no guess by numeric values).
  const fromRows=[];
  for(const row of document.querySelectorAll('tr, .search-row, .search-condition, .condition-row')){
   if(!visible(row))continue;
   const h=txt(row.querySelector('th,label,.tit,.label')||row.firstElementChild);
   if(!/(품목|시작코드)/.test(h)||/(국가|지역)/.test(h))continue;
   fromRows.push(...[...row.querySelectorAll('input')].filter(e=>visible(e)&&!e.readOnly&&!e.disabled&&!['hidden','button','radio'].includes(e.type)&&e.name!=='s_prod_code'));
  }
  const rowUnique=[...new Set(fromRows)];
  if(rowUnique.length===1)return rowUnique[0];
  throw Error(`품목코드 입력칸을 확정할 수 없습니다. 코드 후보 필드: ${unique.map(e=>e.name||e.id||'?').join(', ')||'없음'}. 잘못된 필드에 입력하지 않았습니다.`);
 }
 function nativeRegionLabel(region){
   // Read genuine adjacent K-Stat label. Never replace '전국' with a fake '부산'.
   const r=region?.getBoundingClientRect();if(!r)return '';
   let label='';const root=region.closest('tr')||region.parentElement?.parentElement;
   if(!root)return '';
   for(const node of root.querySelectorAll('span, label, td, a, em, strong')){
    if(node.contains(region)||!visible(node))continue;
    const v=txt(node);if(v!=='부산'&&v!=='전국')continue;
    const rect=node.getBoundingClientRect();
    if(Math.abs(rect.top-r.top)<35&&rect.left>=r.right-10&&rect.left<r.right+330){label=v;break;}
   }
   return label;
 }
 function regionHint(region){
   let hint=document.getElementById('busan-country-region-v44');
   if(!hint){hint=document.createElement('span');hint.id='busan-country-region-v44';hint.style.cssText='display:inline-block;margin-left:6px;padding:2px 6px;background:#edf4fb;border-radius:4px;color:#16577c;font:12px "Malgun Gothic",sans-serif';}
   const genuine=nativeRegionLabel(region);
   hint.textContent=genuine==='부산'?'부산 확인':`부산(60) 입력 · 화면의 실제 선택지역 확인 필요${genuine==='전국'?' [원래 표시는 전국]':''}`;
   region.parentElement?.append(hint);
   return genuine;
 }
 function checkSelect(name,value){const e=field(name);if(e&&e.value!==String(value))throw Error(`${name}: 설정값이 유지되지 않았습니다.`);}
 async function prepare(p){
   if(location.origin!=='https://stat.kita.net'||location.pathname!==TARGET)throw Error('K-Stat 지자체 수출입 → 국가별 페이지에서만 실행합니다.');
   if(p.region!=='60'||p.family!=='MTI'||!/^\d{2,6}$/.test(p.code)||p.code.length!==p.level||![2,3,4,6].includes(p.level))throw Error('품목·지역 조건이 잘못됐습니다.');
   if(!Number.isInteger(p.year)||p.year<2000||p.year>2100||!Number.isInteger(p.month)||p.month<1||p.month>12)throw Error('연월이 잘못됐습니다.');
   optSelect(field('s_cond_gb'),'MTI','품목 분류',{text:'MTI'});
   await wait(300); // K-Stat may repopulate the sub-code selector asynchronously
   optSelect(field('s_cond_unit'),String(p.level),'MTI 자릿수');
   const entries=[['s_year',String(p.year),'연도'],['s_month',String(p.month).padStart(2,'0'),'월'],['s_monthsum_gb',p.interval==='누계'?'2':'1','당월·누계']];
   for(const [name,value,label] of entries)optSelect(field(name),value,label);
   if(field('s_field'))optSelect(field('s_field'),'AMT','화면 표시');
   // Never infer 'US$, %' from a numeric option value: match the actual visible label.
   const unit=textSelect(field('s_measure'),['US$, %','US$,%','US$, ％'],'단위');
   optSelect(field('s_sort'),p.trade==='import'?'THIS_IMP_AMT':'THIS_EXP_AMT','정렬기준');
   const desc=document.getElementById('s_sort_val_desc')||[...document.querySelectorAll('input[type="radio"][name="s_sort_val"]')].find(x=>/desc/i.test(x.value+' '+x.id));
   if(!desc)throw Error('수출입 금액 내림차순 선택 버튼을 찾지 못했습니다.');
   desc.checked=true;events(desc);
   const region=document.querySelector('input[name="s_prod_code"]');fill(region,'60','지역 부산(60)');
   const product=productInput();fill(product,p.code,'품목 '+p.code);
   for(const [name,value] of entries)checkSelect(name,value);
   checkSelect('s_sort',p.trade==='import'?'THIS_IMP_AMT':'THIS_EXP_AMT');
   if(field('s_measure')?.selectedOptions?.[0]&&norm(txt(field('s_measure').selectedOptions[0]))!==norm('US$,%'))throw Error('단위가 US$, %로 유지되지 않았습니다.');
   if(region.value!=='60'||product.value!==p.code)throw Error('지역 또는 품목코드 적용값이 달라졌습니다.');
   await wait(350); // Give K-Stat onchange handlers time to restore/replace dependent controls.
   for(const [name,value] of entries)checkSelect(name,value);
   if(field('s_measure')?.selectedOptions?.[0] && norm(txt(field('s_measure').selectedOptions[0]))!==norm('US$,%'))throw Error('조회 직전 단위가 US$, %에서 변경됐습니다.');
   if(region.value!=='60'||product.value!==p.code)throw Error('조회 직전 지역/품목코드가 변경됐습니다.');
   const shownRegion=regionHint(region);
   return {ok:true,unit,regionLabel:shownRegion,itemField:product.name||product.id||'상품 입력칸',product:p.code,warning:shownRegion==='부산'?'':'지역 표기가 자동으로 부산으로 바뀌지 않았습니다. K-Stat의 실제 조회 대상 지역을 확인해야 합니다.'};
 }
 function probe(){
  // Verify that a country-RANK table actually appeared; never treat a query click as success.
  const found=[];
  for(const table of document.querySelectorAll('table')){
   if(!visible(table))continue;
   const rows=[...table.querySelectorAll('tr')].filter(visible);if(rows.length<3)continue;
   const header=rows.slice(0,Math.min(rows.length,5)).map(r=>[...r.querySelectorAll('th,td')].map(txt).join('|')).join('|');
   if(!/국가/.test(header)||!/(수출|수입)/.test(header))continue;
   const data=rows.slice(1,12).map(r=>[...r.querySelectorAll('td')].map(txt).join('|')).join('\n');
   if(!/\d/.test(data))continue;
   found.push({size:rows.length,data:data.slice(0,2200)});
  }
  const currentUnit=txt(field('s_measure')?.selectedOptions?.[0]);
  const regionValue=field('s_prod_code')?.value||'';
  if(!found.length)return {ready:false,fp:'',count:0,unit:currentUnit,regionCode:regionValue};
  found.sort((a,b)=>b.size-a.size);
  let hash=2166136261;const key=found[0].size+'|'+found[0].data;
  for(const c of key){hash^=c.charCodeAt(0);hash=Math.imul(hash,16777619)>>>0;}
  return {ready:true,fp:hash.toString(16),count:found[0].size-1,unit:currentUnit,regionCode:regionValue};
 }
 function safeDiagnostic(){
  const nodes=[...document.querySelectorAll('input,select,button,img[alt],img[title]')]
   .filter(visible).slice(0,110).map(e=>({tag:e.tagName,name:e.name||'',id:e.id||'',type:e.type||'',alt:e.getAttribute('alt')||'',
    options:e.tagName==='SELECT'?[...e.options].slice(0,15).map(x=>({value:x.value,label:txt(x)})):undefined}));
  return JSON.stringify({page:location.pathname,note:'로그인/수출입 금액/사용자 입력값/쿠키/개인정보 제외',nodes},null,2);
 }
 let lastStatus='연결 준비 중';
 function showPanel(){
  let panel=document.getElementById('busan-country-status-v45');if(panel)return panel;
  panel=document.createElement('section');panel.id='busan-country-status-v45';
  panel.style.cssText='position:fixed;bottom:14px;right:16px;width:min(420px,calc(100vw - 30px));max-height:46vh;overflow:auto;z-index:2147483646;box-sizing:border-box;background:#fff;color:#1d3148;border:2px solid #2c6085;border-radius:12px;padding:13px 15px;box-shadow:0 6px 25px #0003;font:13px/1.55 "Malgun Gothic",sans-serif';
  const title=document.createElement('div');title.textContent='부산 수출입 분석실 · K-Stat 자동조회';title.style.cssText='font-weight:700;font-size:14px;margin-bottom:6px';
  const state=document.createElement('div');state.id='busan-country-status-message-v45';state.setAttribute('role','status');state.style.whiteSpace='pre-wrap';state.textContent=lastStatus;
  const actions=document.createElement('div');actions.style.cssText='display:flex;flex-wrap:wrap;gap:7px;margin-top:9px';
  const btn=(label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.style.cssText='background:#eaf2fa;border:1px solid #a9c3d5;border-radius:6px;padding:7px;color:#1c4b70;cursor:pointer;font:inherit';b.addEventListener('click',fn);actions.appendChild(b);};
  btn('이 탭에서 다시 조회',async()=>{state.textContent='조회 재시도 요청 중…';try{const r=await chrome.runtime.sendMessage({type:'COUNTRY_ANALYSIS_RETRY_V45'});if(!r?.ok)state.textContent=r?.message||r?.error||'재시도 실패';}catch(e){state.textContent='재시도 요청 실패: '+e.message;}});
  btn('진단 내용 복사',async()=>{try{await navigator.clipboard.writeText(safeDiagnostic());state.textContent=lastStatus+'\n(폼 항목명만 클립보드에 복사됨)';}catch(e){state.textContent=lastStatus+'\n복사 실패: '+e.message;}});
  btn('접기',()=>{state.hidden=!state.hidden;actions.style.display=state.hidden?'none':'flex';title.textContent=state.hidden?'부산 분석실 (접힘 · 다시 열려면 클릭)':'부산 수출입 분석실 · K-Stat 자동조회';});
  title.addEventListener('click',()=>{if(state.hidden){state.hidden=false;actions.style.display='flex';title.textContent='부산 수출입 분석실 · K-Stat 자동조회';}});
  panel.append(title,state,actions);(document.body||document.documentElement).append(panel);return panel;
 }
 function updateStatus(k,message){lastStatus=String(message||'');const panel=showPanel();panel.style.borderColor=k==='error'?'#cc4c4c':k==='success'?'#368b64':'#2c6085';document.getElementById('busan-country-status-message-v45').textContent=(k==='error'?'❌ ':k==='success'?'✓ ':'')+lastStatus;}
 showPanel();
 chrome.runtime.onMessage.addListener((m,_sender,reply)=>{
   if(m?.type==='BUSAN_COUNTRY_STATUS_V45'){updateStatus(m.status,m.message);reply({ok:true});return;}
   if(m?.type==='BUSAN_COUNTRY_PREPARE_V44'){prepare(m.payload||{}).then(reply).catch(e=>reply({ok:false,message:String(e.message||e)}));return true;}
   if(m?.type==='BUSAN_COUNTRY_RESULT_PROBE_V44'){try{reply({ok:true,...probe()});}catch(e){reply({ok:false,message:String(e.message||e)});}return;}
 });
}
