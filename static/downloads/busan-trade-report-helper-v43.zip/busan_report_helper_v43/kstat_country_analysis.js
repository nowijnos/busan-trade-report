'use strict';
// Standalone helper for the country-ranking K-Stat page. Does NOT change the
// regular report's K-Stat collector or read cookies, session or data values.
if (!globalThis.__busanCountryAnalysisV43) {
 globalThis.__busanCountryAnalysisV43 = true;
 const TARGET='/stat/kts/prod/ProdCtrImpExpList.screen';
 const t=e=>String(e?.textContent||'').replace(/\s+/g,' ').trim();
 const visible=e=>!!(e&&(e.offsetWidth||e.offsetHeight||e.getClientRects().length));
 const named=n=>document.querySelector(`[name="${n}"]`);
 const inputNamed=n=>document.querySelector(`input[name="${n}"]`);
 const trigger=e=>{for(const type of ['input','change'])e.dispatchEvent(new Event(type,{bubbles:true}));};
 const exact=(value,values)=>values.includes(String(value));
 const selectOption=(e,want,label,required=true)=>{
   if(!e||e.tagName!=='SELECT'){if(required)throw Error(label+' 선택상자를 찾지 못했습니다.');return false;}
   let o=[...e.options].find(o=>o.value===String(want));
   if(!o && /MTI|HS/.test(want))o=[...e.options].find(x=>t(x).toUpperCase()===want);
   if(!o){if(required)throw Error(label+'에 '+want+' 선택값이 없습니다.');return false;}
   e.value=o.value;trigger(e);
   if(e.value!==o.value)throw Error(label+' 선택이 반영되지 않았습니다.');return true;
 };
 const fill=(e,want,label)=>{
   if(!e||e.tagName!=='INPUT'||e.disabled||e.readOnly)throw Error(label+' 입력칸을 찾지 못했습니다.');
   e.value=String(want);trigger(e);
   if(e.value.trim()!==String(want))throw Error(label+' 입력값이 유지되지 않았습니다.');
 };
 function codeField(){
   // Explicit field names, when present, are unambiguous. Do not touch region code.
   const names=['s_item_code','s_item_cd','s_mti_code','s_mti_cd','s_item','s_code','s_prod_item_code','s_prod_item','s_hs_code','s_hs_cd'];
   for(const name of names){const e=inputNamed(name);if(e&&visible(e)&&!e.readOnly)return e;}
   // K-Stat tab is arranged in rows: "지역" | "품목" | "년월".
   // Resolve exactly one editable input in the row whose first label is 품목.
   const candidates=[];
   for(const row of document.querySelectorAll('tr, .search-row, .search-condition')){
     if(!visible(row))continue;
     const head=t(row.querySelector('th,label,.tit,.label')||row.firstElementChild);
     if(!/^품목(?:\s|$|\:)/.test(head))continue;
     const fields=[...row.querySelectorAll('input[type=text],input:not([type])')].filter(e=>visible(e)&&!e.readOnly&&!e.disabled&&e.name!=='s_prod_code');
     for(const f of fields)if(f.maxLength===-1||f.maxLength>=2)candidates.push(f);
   }
   const unique=[...new Set(candidates)];
   if(unique.length===1)return unique[0];
   throw Error('K-Stat 국가별 화면의 품목코드 입력칸을 정확히 찾지 못했습니다. 코드 자동입력은 실행하지 않았습니다. (후보 '+unique.length+'개)');
 }
 function regionLabel(region){
   // Clarify requested Busan code without replacing/forging K-Stat's original label.
   let badge=document.getElementById('busan-code60-country-hint');
   if(!badge){badge=document.createElement('span');badge.id='busan-code60-country-hint';badge.style.cssText='display:inline-block;margin:0 0 0 6px;padding:2px 7px;border-radius:4px;background:#e8f5fa;color:#145d82;font:bold 12px/1.7 "Malgun Gothic",sans-serif;vertical-align:middle';}
   badge.textContent='부산 (코드 60 입력)';if(region?.parentElement && badge.parentElement!==region.parentElement)region.parentElement.append(badge);
 }
 function check(p,field){const v=field.value;if(v!==String(p))throw Error('조회조건 '+field.name+' 값 검증 실패 ('+v+')');}
 async function prepare(p){
   if(location.origin!=='https://stat.kita.net'||location.pathname!==TARGET)throw Error('K-Stat 지자체 수출입 → 국가별 화면이 아닙니다.');
   if(p.region!=='60'||p.family!=='MTI'||!/^\d{2,6}$/.test(p.code)||p.code.length!==p.level||![2,3,4,6].includes(p.level))throw Error('지원하지 않는 지역 또는 품목코드입니다.');
   if(!Number.isInteger(p.year)||p.year<2000||p.year>2100||!Number.isInteger(p.month)||p.month<1||p.month>12)throw Error('연월이 잘못되었습니다.');
   // Page's own onchange may replace the item sub-control after choosing a family.
   const family=named('s_cond_gb');if(family)selectOption(family,'MTI','품목 분류');
   await new Promise(r=>setTimeout(r,220));
   const level=named('s_cond_unit');if(level)selectOption(level,String(p.level),'품목 자릿수',false);
   const settings=[['s_year',String(p.year),'조회 연도'],['s_month',String(p.month).padStart(2,'0'),'조회 월'],['s_monthsum_gb',p.interval==='누계'?'2':'1','당월/누계'],['s_sort',p.trade==='import'?'THIS_IMP_AMT':'THIS_EXP_AMT','정렬기준']];
   for(const [name,v,label] of settings)selectOption(named(name),v,label);
   selectOption(named('s_field'),'AMT','금액 기준',false);
   selectOption(named('s_measure'),'1','단위',false);
   const desc=document.getElementById('s_sort_val_desc')||document.querySelector('input[name="s_sort_val"][value="desc"]');
   if(desc&&desc.type==='radio'){desc.checked=true;trigger(desc);}
   const region=inputNamed('s_prod_code');fill(region,'60','부산 지역코드');
   const product=codeField();fill(product,p.code,'품목코드');regionLabel(region);
   for(const [name,v] of settings)check(v,named(name));check('60',region);check(p.code,product);
   return {ok:true,codeField:product.name||'(품목 입력칸)',note:'품목/지역 코드 입력값 확인. 서버가 선택값을 실제 통계에 적용하는지는 조회 결과로 검증해야 합니다.'};
 }
 function fingerprint(){
   let matches=[];
   for(const table of document.querySelectorAll('table')){
     if(!visible(table))continue;
     const headers=[...table.querySelectorAll('th')].map(t).slice(0,30).join('|');
     if(!/국가/.test(headers))continue;
     let rows=[...table.querySelectorAll('tr')].filter(visible);
     if(rows.length<3)continue;
     const data=rows.slice(1,Math.min(rows.length,12)).map(r=>[...r.querySelectorAll('td')].map(t).join('|')).join('\n');
     if(!/\d/.test(data))continue;
     matches.push({length:rows.length,sample:data.slice(0,1800)});
   }
   if(!matches.length)return {ready:false,fp:'',count:0};
   matches.sort((a,b)=>b.length-a.length);
   const x=matches[0],str=x.sample+'|'+x.length;let h=2166136261;for(const c of str){h^=c.charCodeAt(0);h=Math.imul(h,16777619)>>>0;}
   return {ready:true,fp:h.toString(16),count:x.length-1};
 }
 chrome.runtime.onMessage.addListener((msg,_sender,respond)=>{
   if(msg?.type==='BUSAN_COUNTRY_PREPARE_V43'){prepare(msg.payload||{}).then(respond).catch(e=>respond({ok:false,message:String(e.message||e)}));return true;}
   if(msg?.type==='BUSAN_COUNTRY_RESULT_PROBE_V43'){try{respond({ok:true,...fingerprint()});}catch(e){respond({ok:false,message:String(e.message||e)});}return;}
 });
}
